package com.example.demo.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "order_table")
public class Order {
    
	

	@Id
    @GeneratedValue
	private Long id;

	private int quantity;
	private float tot_price;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="user_id", nullable=false)
	private User user;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="product_id", nullable=false)
	private Product product;
	
	
	private Date createdAt;
	
	public Order()
	{
		
	}
	
    public Order(int quantity, float tot_price) {
		super();
		this.quantity = quantity;
		this.tot_price = tot_price;
	}


	public Long getOrder_Id() {
		return id;
	}
	public void setOrder_Id(Long order_Id) {
		this.id = order_Id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getTot_price() {
		return tot_price;
	}
	public void setTot_price(float tot_price) {
		this.tot_price = tot_price;
	}
	 public Date getCreatedAt() {
	        return createdAt;
	  }

	    public void setCreatedAt(Date createdAt) {
	        this.createdAt = createdAt;
	    }

		@Override
		public String toString() {
			return "Order [order_Id=" + id + ", quantity=" + quantity + ", tot_price=" + tot_price + ", createdAt=" + createdAt + "]";
		}
 
		
	
}
