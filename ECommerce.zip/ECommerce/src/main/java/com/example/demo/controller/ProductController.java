package com.example.demo.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.OrderNotFoundException;
import com.example.demo.exceptions.ProductNotFoundException;
import com.example.demo.model.Product;


@RestController
public class ProductController {
	
	@Autowired
	private ProductRepository repo;


	public void setRepo(ProductRepository repo) {
		this.repo = repo;
	}

	@GetMapping("/products")
	public  Iterable<Product> all() {
	  
			return repo.findAll();
	}
	
	@RequestMapping(name="/products/{id}",method=RequestMethod.GET)
	public Product getProduct(@PathVariable("id") Long id)
	{   
	    Optional<Product> prod= repo.findById(id); 
//	    boolean valueExists= prod.isEmpty();
//	    if(valueExists)
//	    return prod.get();
//	    

//	    return repo.findById(id)
//	    	      .orElseThrow(() -> {new ProductNotFoundException(id);});
	 Product retrievedProd= prod.get();
	 return retrievedProd;
	}
	
	
	@RequestMapping(name="/products",method=RequestMethod.POST , consumes="application/json")
	public Product createProduct(@RequestBody Product prod)
	{   
		
		prod=repo.save(prod);
	    return prod;	
	}
	
	
	 @PutMapping("/products/{id}")
	  public Product replaceProduct(@RequestBody Product newProd, @PathVariable("id") Long id) {
	    
	    Optional<Product> product= repo.findById(id)
	      .map(prod -> {
	        prod.setProd_Name(newProd.getProd_Name());
	        prod.setProd_Type(newProd.getProd_Type());
	        prod.setProd_price(newProd.getProd_price());
	        return repo.save(prod);
	      });
//	      .orElseGet(() -> {
//	        newProd.setId(id);
//	        return repository.save(newProd);
//	      });
	      
	      Product retrivedProd= product.get();
	      return retrivedProd;
	  }
	
	 @DeleteMapping("/products/{id}")
	 public Map < String, Boolean > deleteProduct(@PathVariable Long id) throws  ProductNotFoundException {
	   
//		 repo.deleteById(id);
		 Product product = repo.findById(id)
		            .orElseThrow(() -> new ProductNotFoundException(id));

		        repo.delete(product);
		        Map < String, Boolean > response = new HashMap < > ();
		        response.put("deleted", Boolean.TRUE);
		        return response;
	    
	    
	  }
	 
	

}
