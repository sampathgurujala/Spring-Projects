package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.exceptions.ProductNotFoundException;
import com.example.demo.exceptions.UserNotFoundException;
import com.example.demo.model.Product;
import com.example.demo.model.User;

public class UserController {
	
	@Autowired
	private UserRepository repo;


	public void setRepo(UserRepository repo) {
		this.repo = repo;
	}

	@GetMapping("/users")
	public  Iterable<User> all() {
	  
			return  repo.findAll();
	}
	
	
	@RequestMapping(name="/users/{id}",method=RequestMethod.GET)
	public User getUser(@PathVariable Long id)
	{   
	    Optional<User> user= repo.findById(id); 
//	    boolean valueExists= prod.isEmpty();
//	    if(valueExists)
//	    return prod.get();
//	    

//	    return repo.findById(id)
//	    	      .orElseThrow(() -> {new ProductNotFoundException(id);});
	 User retrievedUser = user.get();
	 return retrievedUser;
	}
	
	
	@RequestMapping(name="/users",method=RequestMethod.POST , consumes="application/json")
	public User createUser(@RequestBody User user)
	{   
		
		user=repo.save(user);
	    return user;	
	}
	
	
	 @PutMapping("/users/{id}")
	  public User replaceUser(@RequestBody User newUser, @PathVariable Long id) {
	    
	    Optional<User> user= repo.findById(id)
	      .map(oldUser -> {
	        oldUser.setUserName(newUser.getUserName());
	        oldUser.setCity(newUser.getCity());
	        oldUser.setSt_name(newUser.getSt_name());
	        
	         return repo.save(oldUser);
	      });
//	      .orElseGet(() -> {
//	        newProd.setId(id);
//	        return repository.save(newProd);
//	      });
	      
	      User retrivedUser= user.get();
	      return retrivedUser;
	  }
	
	 @DeleteMapping("/users/{id}")
	  public Map < String, Boolean > deleteUser(@PathVariable Long id) throws UserNotFoundException {
	//    repo.deleteById(id);
	    
		 User user = repo.findById(id)
		            .orElseThrow(() -> new UserNotFoundException(id));

		        repo.delete(user);
		        Map < String, Boolean > response = new HashMap < > ();
		        response.put("deleted", Boolean.TRUE);
		        return response;

	  }
	 
	

}
