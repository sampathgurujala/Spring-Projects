package com.example.demo.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "user_table")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String userName;
	private String city;
	private String st_name;
	
	 @OneToMany(mappedBy="user")
	 private List<Order> orders;
	
	public User( String userName, String city, String st_name) {
		super();
		this.userName = userName;
		this.city = city;
		this.st_name = st_name;
	}
	
	public Long getId() {
		return id;
	}
	public void seId(Long user_Id) {
		this.id = user_Id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSt_name() {
		return st_name;
	}
	public void setSt_name(String st_name) {
		this.st_name = st_name;
	}
	
	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	
	@Override
	public String toString() {
		return "User [user_Id=" + id + ", userName=" + userName + ", city=" + city + ", st_name=" + st_name + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(city, st_name, userName, id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(city, other.city) && Objects.equals(st_name, other.st_name)
				&& Objects.equals(userName, other.userName) && Objects.equals(id, other.id);
	}
	

	
}
