package com.example.demo.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "product_table")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String prod_Name;
	private String prod_Type;
	private double prod_price; 
	
	@OneToMany(mappedBy="product")
	private List<Order> orders;
	
	public Product() 
	{
		
	}
	
	public Product( String prod_Name, String prod_Type, double prod_price) {
		super();
		this.prod_Name = prod_Name;
		this.prod_Type = prod_Type;
	    this.prod_price = prod_price;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long product_Id) {
		this.id = product_Id;
	}
	public String getProd_Name() {
		return prod_Name;
	}
	public void setProd_Name(String prod_Name) {
		this.prod_Name = prod_Name;
	}
	public String getProd_Type() {
		return prod_Type;
	}
	public void setProd_Type(String prod_Type) {
		this.prod_Type = prod_Type;
	}
	
	public double getProd_price() {
		return prod_price;
	}

	public void setProd_price(double prod_price) {
		this.prod_price = prod_price;
	}

    
	@Override
	public int hashCode() {
		return Objects.hash(id, prod_Name, prod_Type, prod_price);
	}

	@Override
	public String toString() {
		return "Product [prod_Id=" + id + ", prod_Name=" + prod_Name + ", prod_Type=" + prod_Type + ", prod_price="
				+ prod_price + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(id, other.id) && Objects.equals(prod_Name, other.prod_Name)
				&& Objects.equals(prod_Type, other.prod_Type)
				&& Double.doubleToLongBits(prod_price) == Double.doubleToLongBits(other.prod_price);
	}

//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Product other = (Product) obj;
//		return Objects.equals(prod_Id, other.prod_Id) && Objects.equals(prod_Name, other.prod_Name)
//				&& Objects.equals(prod_Type, other.prod_Type);
//	}
//	
	
	
	
}
