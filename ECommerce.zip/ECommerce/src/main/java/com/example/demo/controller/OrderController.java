package com.example.demo.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.OrderNotFoundException;
import com.example.demo.exceptions.ProductNotFoundException;
import com.example.demo.exceptions.UserNotFoundException;
import com.example.demo.model.Order;
import com.example.demo.model.Product;
import com.example.demo.model.User;

@RestController
public class OrderController {

	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private UserRepository  userRepository;

	 @GetMapping("/users/{userId}/orders")
	 public List <Order> getOrdersByUser(@PathVariable(value = "userId") Long userId) {
	        return orderRepository.findByUserId(userId);
	  }

	 @GetMapping("/products/{productId}/orders")
	 public List <Order> getOrdersByProduct(@PathVariable(value = "productId") Long productId) {
	        return orderRepository.findByProductId(productId);
	  }
	 
	 
	 @PostMapping("/users/{userId}/products/{productId}/orders")
	    public Order createOrder(@PathVariable(value = "userId") Long userId,@PathVariable(value = "productId") Long productId,
	     @RequestBody Order order) throws UserNotFoundException,ProductNotFoundException  {
	        User retrievedUser=  userRepository.findById(userId).map(user -> {
	            order.setUser(user);
	            return user;
	        }).orElseThrow(() -> new UserNotFoundException(userId));
	        
	        Product retrievedProduct= productRepository.findById(productId).map(product -> {
	            order.setProduct(product);
	            return product;
	        }).orElseThrow(() -> new ProductNotFoundException(productId));
	        
//	        LocalDate localdate = java.time.LocalDate.now();
//	        Date date = java.sql.Date.valueOf(localdate);
//	        
	        return orderRepository.save(order);

	    }
	 
	 @PutMapping("/users/{userId}/products/{productId}/orders/{orderId}")
	    public Order updateOrder(@PathVariable(value = "userId") Long userId,
	        @PathVariable(value = "productId") Long productId,@PathVariable(value = "orderId") Long orderId,
	        @RequestBody Order orderRequest)
	    throws OrderNotFoundException,UserNotFoundException,ProductNotFoundException {
	        if (!userRepository.existsById(userId)) {
	            throw new UserNotFoundException(userId);
	        }
	        if (!productRepository.existsById(productId)) {
	            throw new ProductNotFoundException(productId);
	        }
	        if (!orderRepository.existsById(orderId)) {
	            throw new OrderNotFoundException(orderId);
	        }


	        return orderRepository.findById(orderId).map(order -> {
	            order.setQuantity(orderRequest.getQuantity());
	            order.setTot_price(orderRequest.getTot_price());
	            order.setCreatedAt(orderRequest.getCreatedAt());
	            return orderRepository.save(order);
	        }).orElseThrow(() -> new OrderNotFoundException(orderId));
	    }
	 
	 @DeleteMapping("/users/{userId}/orders/{orderId}")
	    public ResponseEntity < ? > deleteOrder(@PathVariable(value = "userId") Long userId,
	        @PathVariable(value = "productId") Long productId ,@PathVariable(value = "orderId") Long orderId ) 
	        		throws  OrderNotFoundException,UserNotFoundException,ProductNotFoundException {
	       
		 return orderRepository.findByIdAndUserId(orderId,userId).map(order -> {
	            orderRepository.delete(order);
	            return ResponseEntity.ok().build();
	        }).orElseThrow(() -> new OrderNotFoundException(orderId));
	    }
	
}
