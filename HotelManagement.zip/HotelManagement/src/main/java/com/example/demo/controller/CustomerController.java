package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.CustomerNotFoundException;
import com.example.demo.model.Customer;



@RestController
public class CustomerController {

	@Autowired
	private CustomerRepository repo;
	
	@GetMapping("/customers")
	public  Iterable<Customer> all() {
	  
			return  repo.findAll();
	}
	
	@RequestMapping(name="/customers/{id}",method=RequestMethod.GET)
	public Customer getCustomer(@PathVariable Long id)
	{   
	    Optional<Customer> cust= repo.findById(id); 
//	    boolean valueExists= prod.isEmpty();
//	    if(valueExists)
//	    return prod.get();
//	    

//	    return repo.findById(id)
//	    	      .orElseThrow(() -> {new ProductNotFoundException(id);});
	 Customer retrievedCust= cust.get();
	 return retrievedCust;
	}
	
	
	@RequestMapping(name="/customers",method=RequestMethod.POST , consumes="application/json")
	public Customer createCustomer(@RequestBody Customer cust)
	{   
		
		cust=repo.save(cust);
	    return cust;	
	}
	
	
	 @PutMapping("/customers/{id}")
	  public Customer replaceCustomer(@RequestBody Customer newCust, @PathVariable Long id) {
	    
	    Optional<Customer> customer= repo.findById(id)
	      .map(cust -> {
	        cust.setCustName(newCust.getCustName());
	        cust.setAddress(newCust.getAddress());
	        
	        return repo.save(cust);
	      });
//	      .orElseGet(() -> {
//	        newProd.setId(id);
//	        return repository.save(newProd);
//	      });
	      
	      Customer retrivedCust= customer.get();
	      return retrivedCust;
	  }
	
	 @DeleteMapping("/customers/{id}")
	 public  Map < String, Boolean > deleteCustomer(@PathVariable Long id) throws CustomerNotFoundException {
	  //  repo.deleteById(id);
	    
	    Customer customer = repo.findById(id)
	            .orElseThrow(() -> new CustomerNotFoundException(id));

	        repo.delete(customer);
	        Map < String, Boolean > response = new HashMap < > ();
	        response.put("deleted", Boolean.TRUE);
	        return response;

	  }
	 
	

}
