package com.example.demo.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "booking_table")
public class Booking {

@Id
@GeneratedValue	
private Long id;

@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="customer_id", nullable=false)
private Customer customer;

@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="room_id", nullable=false)
private Room room;

private int members;

private Date createdAt;


public Booking() {
	super();
	// TODO Auto-generated constructor stub
}


public Booking(int members) {
	super();
	this.members = members;
}


public Long getId() {
	return id;
}


public void setId(Long id) {
	this.id = id;
}


public Customer getCustomer() {
	return customer;
}


public void setCustomer(Customer customer) {
	this.customer = customer;
}


public Room getRoom() {
	return room;
}


public void setRoom(Room room) {
	this.room = room;
}



public int getMembers() {
	return members;
}


public void setMembers(int members) {
	this.members = members;
}


public Date getCreatedAt() {
	return createdAt;
}


public void setCreatedAt(Date createdAt) {
	this.createdAt = createdAt;
}


@Override
public String toString() {
	return "Booking [id=" + id + ", members=" + members + ", createdAt=" + createdAt + "]";
}


	
}
