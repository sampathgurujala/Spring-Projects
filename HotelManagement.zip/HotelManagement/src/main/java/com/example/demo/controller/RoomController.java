package com.example.demo.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.CustomerNotFoundException;
import com.example.demo.exceptions.RoomNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.model.Room;

@RestController
public class RoomController {

	@Autowired
	private RoomRepository repo;
	 
	public void setRepo(RoomRepository repo) {
		this.repo = repo;
	}
	
	@GetMapping("/rooms")
	public  Iterable<Room> all() {
	  
			return  repo.findAll();
	}
	
//	@RequestMapping(name="/rooms/{id}",method=RequestMethod.GET)
	@GetMapping("/rooms/{id}")
	public Room getRoom(@PathVariable("id") Long id)
	{   
	    Optional<Room> room= repo.findById(id); 
//	    boolean valueExists= prod.isEmpty();
//	    if(valueExists)
//	    return prod.get();
//	    

//	    return repo.findById(id)
//	    	      .orElseThrow(() -> {new ProductNotFoundException(id);});
	 Room retrievedRoom= room.get();
	 return retrievedRoom;
	}
	
	
//	@RequestMapping(name="/rooms",method=RequestMethod.POST , consumes="application/json")
	@PostMapping("/rooms")
	public Room createRoom(@RequestBody Room room)
	{   
		
		room=repo.save(room);
	    return room;	
	}
	
	
	 @PutMapping("/rooms/{id}")
	  public Room replaceRoom(@RequestBody Room newRoom, @PathVariable("id") Long id) {
	    
	    Optional<Room> room = repo.findById(id)
	      .map( eachRoom -> {
	        eachRoom.setFlrNo(newRoom.getFlrNo());
	        eachRoom.setNoOfBeds(newRoom.getNoOfBeds());
	        
	        
	        return repo.save(eachRoom);
	      });
//	      .orElseGet(() -> {
//	        newProd.setId(id);
//	        return repository.save(newProd);
//	      });
	      
	      Room retrivedRoom = room.get();
	      return retrivedRoom;
	  }
	
	 @DeleteMapping("/rooms/{id}")
	 public    Map <String, Boolean> deleteRoom(@PathVariable("id") Long id) throws RoomNotFoundException {
	   // repo.deleteById(id);
		   Room room = repo.findById(id)
		            .orElseThrow(() -> new RoomNotFoundException(id));

		        repo.delete(room);
		        Map < String, Boolean > response = new HashMap < > ();
		        response.put("deleted", Boolean.TRUE);
		        return response;

	  }
	 

}
