package com.example.demo.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "room_table")
public class Room {

@Id
@GeneratedValue(strategy=GenerationType.AUTO)	
private Long id;
private Long flrNo;
private Long noOfBeds;

@OneToMany(mappedBy="room")
private List<Booking> bookings;


public Room(Long flrNo, Long noOfBeds) {
	super();
	this.flrNo = flrNo;
	this.noOfBeds = noOfBeds;
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public Long getFlrNo() {
	return flrNo;
}
public void setFlrNo(Long flrNo) {
	this.flrNo = flrNo;
}
public Long getNoOfBeds() {
	return noOfBeds;
}
public void setNoOfBeds(Long noOfBeds) {
	this.noOfBeds = noOfBeds;
}

@Override
public String toString() {
	return "Room [room_Id=" + id + ", flrNo=" + flrNo + ", noOfBeds=" + noOfBeds + "]";
}



}
