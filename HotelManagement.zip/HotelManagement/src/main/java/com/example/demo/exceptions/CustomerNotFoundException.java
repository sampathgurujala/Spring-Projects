package com.example.demo.exceptions;

public class CustomerNotFoundException extends RuntimeException {

	public CustomerNotFoundException(Long id) {
	    super("Could not find Customer " + id);
	  }
}
