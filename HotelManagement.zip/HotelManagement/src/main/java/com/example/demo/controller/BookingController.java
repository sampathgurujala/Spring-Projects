package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.BookingNotFoundException;
import com.example.demo.exceptions.CustomerNotFoundException;
import com.example.demo.exceptions.RoomNotFoundException;
import com.example.demo.model.Booking;
import com.example.demo.model.Customer;
import com.example.demo.model.Room;

@RestController
public class BookingController {

	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
	private RoomRepository roomRepository;
	
	@Autowired
	private CustomerRepository  customerRepository;

	 @GetMapping("/customers/{customerId}/bookings")
	 public List <Booking> getBookingsByCustomer(@PathVariable(value = "customerId") Long customerId) {
	        return bookingRepository.findByCustomerId(customerId);
	  }

	 @GetMapping("/rooms/{roomId}/bookings")
	 public List <Booking> getBookingsByRoom(@PathVariable(value = "roomId") Long roomId) {
	        return bookingRepository.findByRoomId(roomId);
	  }
	 
	 @PostMapping("/customers/{customerId}/rooms/{roomId}/bookings")
	    public Booking createBooking (@PathVariable(value = "customerId") Long customerId,@PathVariable(value = "roomId") Long roomId,
	     @RequestBody Booking booking) throws CustomerNotFoundException,RoomNotFoundException {
	        Customer retrievedCustomer =  customerRepository.findById(customerId).map(customer -> {
	            booking.setCustomer(customer);
	            return customer;
	        }).orElseThrow(() -> new CustomerNotFoundException(customerId));
	        
	        Room retrievedroom= roomRepository.findById(roomId).map(room -> {
	            booking.setRoom(room);
	            return room;
	        }).orElseThrow(() -> new RoomNotFoundException(roomId));
	        
//	        LocalDate localdate = java.time.LocalDate.now();
//	        Date date = java.sql.Date.valueOf(localdate);
//	        
	        return bookingRepository.save(booking);

	    }
	 @PutMapping("/customers/{customerId}/rooms/{roomId}/bookings/{bookingId}")
	    public Booking updateBooking(@PathVariable(value = "customerId") Long customerId,
	        @PathVariable(value = "roomId") Long roomId,@PathVariable(value = "bookingId") Long bookingId,
	        @RequestBody Booking bookingRequest)
	    throws BookingNotFoundException,CustomerNotFoundException,RoomNotFoundException {
	        if (!customerRepository.existsById(customerId)) {
	            throw new CustomerNotFoundException(customerId);
	        }
	        if (!roomRepository.existsById(roomId)) {
	            throw new RoomNotFoundException(roomId);
	        }
	        if (!bookingRepository.existsById(bookingId)) {
	            throw new BookingNotFoundException(bookingId);
	        }


	        return bookingRepository.findById(bookingId).map(booking -> {
	            
	            booking.setMembers(bookingRequest.getMembers());
	            booking.setCreatedAt(bookingRequest.getCreatedAt());
	            return bookingRepository.save(booking);
	        }).orElseThrow(() -> new BookingNotFoundException(bookingId));
	    }
	 
	 @DeleteMapping("/customers/{customerId}/bookings/{bookingId}")
	    public ResponseEntity < ? > deleteBooking(@PathVariable(value = "customerId") Long customerId,
	        @PathVariable(value = "bookingId") Long bookingId ) 
	        		throws  BookingNotFoundException,CustomerNotFoundException {
	       
		 return bookingRepository.findByIdAndCustomerId(bookingId,customerId).map(booking -> {
	            bookingRepository.delete(booking);
	            return ResponseEntity.ok().build();
	        }).orElseThrow(() -> new BookingNotFoundException(bookingId));
	    }


	
}
