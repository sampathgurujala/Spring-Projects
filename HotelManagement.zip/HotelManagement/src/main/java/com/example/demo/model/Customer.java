package com.example.demo.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "customer_table")
public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String custName;
	private String address;
	
	@OneToMany(mappedBy="customer")
	private List<Booking> bookings;
	
	
	public Customer(String custName, String address) {
		super();
		this.custName = custName;
		this.address = address;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long cust_Id) {
		this.id = cust_Id;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customer_Id=" + id + ", custName=" + custName + ", address=" + address + "]";
	}
	
	
	
}
